import React from 'react';

function TaskList(props) {
    return (
        <div>
            Task List
        </div>
    );
}

export default TaskList;