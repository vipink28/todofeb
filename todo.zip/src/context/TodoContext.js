import { createContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const TodoContext = createContext();

export const TodoProvider = ({ children }) => {
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const [userData, setUserData] = useState();

  const [taskList, setTaskList] = useState([]);
  const [latestTask, setLatestTask] = useState({});
  const [recentTask, setRecentTask] = useState([]);

  const onRegister = async (formData) => {
    const obj = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    };

    const checkUser = await fetch(
      `http://localhost:5000/user?email=${formData.email}`,
      { method: "GET" }
    );

    const user = await checkUser.json();

    if (user.length > 0) {
      setMessage("User already exist");
    } else {
      const response = await fetch("http://localhost:5000/user", obj);

      if (response.ok) {
        const user = await response.json();
        console.log(user);
        setMessage("user created successfully");
        const userData = JSON.stringify(user);
        localStorage.setItem("user", userData);
        setUserData({ name: user.name });
        navigate("/task-list");
      } else {
        setMessage("something went wrong");
      }
    }
  };
  const onLogin = async (formData) => {
    const response = await fetch(
      `http://localhost:5000/user?email=${formData.email}&password=${formData.password}`,
      { method: "GET" }
    );
    console.log(response);
    const user = await response.json();
    if (user.length > 0) {
      setMessage("logged in successfully");
      const userData = JSON.stringify(user[0]);
      localStorage.setItem("user", userData);
      setUserData({ name: user[0].name, id: user[0].id });
      navigate("/task-list");
    } else {
      setMessage("something went wrong");
    }
  };
  //effects

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user !== "undefined") {
      const userObj = JSON.parse(user);
      setUserData(userObj);
    }
  }, []);

  //create Task

  const createTask = async (formData) => {
    const obj = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    };
    const response = await fetch("http://localhost:5000/tasks/id", obj);
    if (response.ok) {
      setMessage("Task created successfully");
      getTaskList();
    } else {
      setMessage("something went wrong");
    }
  };

  //get all tasks

  const getTaskList = async () => {
    const response = await fetch(
      `http://localhost:5000/tasks?userId=${userData.id}`,
      { method: "GET" }
    );
    if (response.ok) {
      const tasks = await response.json();
      setTaskList(tasks);
      const latestTask = tasks[tasks.length - 1];
      setLatestTask(latestTask);
      const recentTask = tasks.slice(-3);
      setRecentTask(recentTask);
    }
  };

  useEffect(()=>{
    if(userData){
      getTaskList();
    }
  }, [userData])

  return (
    <TodoContext.Provider
      value={{
        message,
        onRegister,
        onLogin,
        userData,
        setUserData,
        setMessage,
        createTask,
        getTaskList,
        recentTask,
        latestTask,
        taskList
      }}
    >
      {children}
    </TodoContext.Provider>
  );
};

export default TodoContext;
